# go2_nav2_bridge

`go2_nav2_bridge` übersetzt Nav2-nahe Fahrkommandos auf die offizielle Unitree-Go2-Sportmode-API, **ohne** dass die reale Roboterrotation die von Nav2 gewünschte Kartenbahn verändern muss.

Die Bridge ist für ein spezielles Modell gebaut:

- **RTAB-Map / reale Localization** sieht die **echte** Odometrie des Roboters.
- **Nav2** sieht eine **virtuelle** Odometrie.
- Nav2 darf den Roboter als **nicht-holonom** behandeln (`vor/zurück + drehen`).
- Die Bridge interpretiert Nav2-`angular.z` als Änderung eines **virtuellen Fahrtrichtungswinkels** (`fake_yaw`).
- Die reale Basisrotation folgt stattdessen einem **separaten Look-Yaw-Ziel**.
- Die reale Translation wird so berechnet, dass der Roboter die **von Nav2 gewünschte Bahn** fährt, auch wenn er dabei anders ausgerichtet ist.

Das ist absichtlich **nicht** die Standard-`cmd_vel`-Semantik von Nav2. Genau deshalb publiziert die Bridge eine **eigene virtuelle Nav2-Odom/TF-Sicht**.

---

## Was in dieser Version wirklich implementiert ist

- `velocity_move`-Modus
- `balance_stand`-Modus
- Umschaltung zwischen beiden Modi per Topic
- relativer `look_yaw_delta` im `velocity_move`-Modus
- virtuelle Nav2-Odometrie (`/odom_nav2` standardmäßig)
- optionaler virtueller Nav2-TF (`odom_nav2 -> base_link_nav2`)
- Watchdog mit `StopMove(...)`
- `BalanceStand(...)` und `Euler(...)` im Standmodus
- optionale Gait-Vorgabe beim Start

---

## Kritische Designentscheidung

Die Bridge setzt die virtuelle Nav2-Ausrichtung **nicht sprunghaft** auf neue Winkel, sondern integriert sie kontinuierlich aus Nav2-`angular.z`.

Warum:

- Nav2 erwartet eine **glatte** Odom-/TF-Rückmeldung.
- Harte Yaw-Sprünge können lokale Controller und Fortschrittslogik destabilisieren.
- Deshalb gilt hier:
  - `x/y/z` für Nav2 kommen aus der **realen** SportModeState-Odometrie.
  - `yaw` für Nav2 ist **virtuell** und wird aus `cmd_vel.angular.z` integriert.

Dadurch bleibt die Bahn echt, die für Nav2 sichtbare Orientierung aber virtuell.

---

## Gegen welche Unitree-Dateien geprüft wurde

Die verwendeten Unitree-Typen und Methoden wurden gegen die hochgeladenen offiziellen SDKs geprüft.

Direkt bestätigt in `unitree_ros2-master`:

- `example/src/include/common/ros2_sport_client.h`
- `example/src/src/common/ros2_sport_client.cpp`
- `example/src/src/go2/go2_sport_client.cpp`
- `cyclonedds_ws/src/unitree/unitree_go/msg/SportModeState.msg`
- `cyclonedds_ws/src/unitree/unitree_go/msg/IMUState.msg`

Direkt bestätigt wurden daraus:

- `unitree_api::msg::Request`
- `unitree_go::msg::SportModeState`
- `unitree_go::msg::IMUState`
- `SportClient::Move(req, vx, vy, vyaw)`
- `SportClient::StopMove(req)`
- `SportClient::BalanceStand(req)`
- `SportClient::Euler(req, roll, pitch, yaw)`
- `SportClient::StandUp(req)`
- `SportClient::SwitchJoystick(req, flag)`

Die zusätzlich verwendeten ROS-Typen stammen **nicht** aus dem Unitree-SDK, sondern sind normale ROS-2-Typen:

- `geometry_msgs/msg/Twist`
- `geometry_msgs/msg/Vector3`
- `nav_msgs/msg/Odometry`
- `std_msgs/msg/String`
- `std_msgs/msg/Float32`

---

## Architektur

### Reale Seite

Eingang:

- `lf/sportmodestate` (konfigurierbar)

Diese Seite liefert:

- echte Position `position[3]`
- echte Weltgeschwindigkeit `velocity[3]`
- echte IMU-Yaw `imu_state.rpy[2]`

Diese Daten bleiben die **reale** Bewegungswahrheit des Roboters.

### Virtuelle Nav2-Seite

Eingang:

- `cmd_vel_topic` (standardmäßig `/cmd_vel_nav2`)

Nav2 soll hier idealerweise als **nicht-holonome** Plattform laufen:

- `linear.x` = gewünschte Vorwärtsbewegung im virtuellen Nav2-Frame
- `angular.z` = Änderung der **virtuellen Fahrtrichtung**
- `linear.y` wird standardmäßig ignoriert

Die Bridge erzeugt daraus:

- virtuellen Nav2-Yaw `fake_yaw`
- virtuelle Nav2-Odometrie `/odom_nav2`
- optional virtuellen TF `odom_nav2 -> base_link_nav2`

### Look-/Ausrichtungsseite

Eingang:

- `look_yaw_delta_topic` (standardmäßig `/look_yaw_delta`)

Semantik:

- relativer Winkel in Radiant
- Beispiel: `-0.349066` für ungefähr **20° nach rechts**
- dieser Winkel verändert die **reale Soll-Basisrotation**, nicht die Nav2-Bahn

### Standmodus-Seite

Eingänge:

- `/control_mode_cmd` (`velocity_move` oder `balance_stand`)
- `/balance_rpy_cmd` (`geometry_msgs/Vector3`, roll/pitch/yaw in Radiant)

Im `balance_stand`-Modus sendet die Bridge:

- `StopMove(...)`
- `BalanceStand(...)`
- `Euler(roll, pitch, yaw)`

---

## Wie die Kinematik in `velocity_move` funktioniert

### 1. Virtuelle Fahrtrichtung aus Nav2

Die Bridge hält einen Zustand `fake_yaw`.

Er wird kontinuierlich aus Nav2 berechnet:

```text
fake_yaw(t+dt) = fake_yaw(t) + cmd_vel.angular.z * dt
```

Wichtig:

- Das ist **nicht** die echte Basisrotation.
- Das ist die von Nav2 gedachte Fahrtrichtung.

### 2. Gewünschte Kartenbewegung

Aus Nav2-`linear.x` und `fake_yaw` wird die gewünschte Weltbewegung berechnet:

```text
world_v = R(fake_yaw) * [linear.x, linear.y]
```

Standardmäßig ist `linear.y = 0`, weil Nav2 als nicht-holonom behandelt werden soll.

### 3. Umrechnung in den echten Roboterrahmen

Die reale Basis hat ihre eigene aktuelle Yaw `real_yaw`.

Die gewünschte Weltbewegung wird deshalb in den echten Körperrahmen des Go2 zurückrotiert:

```text
body_v = R(-real_yaw) * world_v
```

Diese `body_v`-Komponenten gehen dann in:

```text
Move(vx, vy, vyaw)
```

Das ist der Kern dafür, dass die **Bahn** von Nav2 kommt, die **Blickrichtung** aber separat sein darf.

### 4. Reale Basisrotation

Die reale Basisrotation folgt **nicht** `fake_yaw`.

Sie folgt einem separaten Sollwert `look_yaw_target_world`, der mit `look_yaw_delta` verändert wird.

Daraus entsteht die reale Yaw-Regelung:

```text
yaw_error = look_yaw_target_world - real_yaw
body_wz = clamp(kp * yaw_error)
```

---

## Erwartetes Verhalten in den besprochenen Durchgängen

### Durchgang 1

Nav2: vorwärts, 90° rechts, wiederhole 4x. Kein manueller Look-Yaw.

Ergebnis dieser Bridge:

- Der Roboter fährt die von Nav2 gewünschte Quadratbahn in der Karte.
- Die reale Basisrotation bleibt konstant.
- Es gibt **keine echte Drehung**, nur eine Änderung von `fake_yaw`.

### Durchgang 2

Gleiche Nav2-Bahn wie in Durchgang 1. Während der ersten Strecke kommt `look_yaw_delta = -20°`.

Ergebnis dieser Bridge:

- Der Roboter fährt **dieselbe Kartenbahn** wie in Durchgang 1.
- Die reale Basis dreht sich zusätzlich um 20° nach rechts.
- Die Übersetzung in `vx/vy` kompensiert diese andere Ausrichtung.
- Am Ende ist der Roboter real um 20° anders ausgerichtet, die Bahn bleibt gleich.

### Durchgang 3

Nav2 fährt vorwärts, danach wird auf `balance_stand` gewechselt.

Ergebnis dieser Bridge:

- Die Bridge sendet `StopMove(...)`.
- Danach `BalanceStand(...)` und `Euler(...)`.
- Der Roboter hält an und bleibt im Standmodus.

Wichtig:

- **Diese Bridge cancelt keinen Nav2-Task.**
- Das muss ein anderer Teil des Projekts übernehmen.

Dieser Punkt ist absichtlich nur dokumentiert, nicht implementiert.

---

## Topics

### Eingänge

#### `cmd_vel_topic`
Typ: `geometry_msgs/msg/Twist`

Standard:

```yaml
/cmd_vel_nav2
```

#### `sport_state_topic`
Typ: `unitree_go/msg/SportModeState`

Standard:

```yaml
lf/sportmodestate
```

#### `control_mode_topic`
Typ: `std_msgs/msg/String`

Werte:

- `velocity_move`
- `balance_stand`

#### `look_yaw_delta_topic`
Typ: `std_msgs/msg/Float32`

Semantik:

- relativer Yaw-Offset in Radiant
- verändert das reale Blickziel der Basis

#### `balance_rpy_topic`
Typ: `geometry_msgs/msg/Vector3`

Semantik:

- `x = roll`
- `y = pitch`
- `z = yaw`

### Ausgänge

#### `/api/sport/request`
Typ: `unitree_api/msg/Request`

#### `nav2_odom_topic`
Typ: `nav_msgs/msg/Odometry`

Standard:

```yaml
/odom_nav2
```

#### virtueller TF

Wenn `publish_nav2_tf=true`:

```text
odom_nav2 -> base_link_nav2
```

---

## Parameter

```yaml
go2_nav2_bridge:
  ros__parameters:
    cmd_vel_topic: /cmd_vel_nav2
    sport_state_topic: lf/sportmodestate
    control_mode_topic: /control_mode_cmd
    look_yaw_delta_topic: /look_yaw_delta
    balance_rpy_topic: /balance_rpy_cmd

    nav2_odom_topic: /odom_nav2
    nav2_odom_frame: odom_nav2
    nav2_base_frame: base_link_nav2
    publish_nav2_odom: true
    publish_nav2_tf: true

    watchdog_timeout_sec: 0.30
    command_publish_rate_hz: 20.0

    max_vx: 0.40
    max_vy: 0.25
    max_wz: 0.60
    look_yaw_kp: 1.5

    nav2_linear_y_enabled: false

    require_standup_on_start: false
    enable_joystick_override: false
    gait_mode: no_change
```

### Wichtige Parameter

#### `nav2_linear_y_enabled`
Standard: `false`

Das sollte für den hier geplanten Betrieb mit Nav2 als nicht-holonome Plattform **normalerweise `false` bleiben**.

#### `publish_nav2_tf`
Standard: `true`

Die Bridge kann die virtuelle TF-Kette selbst ausgeben.

#### `look_yaw_kp`
Yaw-P-Regler für die reale Basisorientierung.

---

## Build

```bash
cd ~/your_ws
colcon build --packages-select go2_nav2_bridge
source install/setup.bash
```

## Start

```bash
ros2 run go2_nav2_bridge go2_nav2_bridge \
  --ros-args --params-file src/go2_nav2_bridge/config/bridge.yaml
```

---

## Integration mit RTAB-Map und Nav2

### Empfohlene Trennung

- **RTAB-Map / reale Localization**: reale Odom/TF
- **Nav2**: virtuelle Odom/TF aus dieser Bridge

### Nicht mischen

Nav2 sollte **nicht gleichzeitig** die reale und die virtuelle Basisorientierung sehen.

Wenn Nav2 die echte Orientierung bekäme, während `angular.z` in der Bridge nur `fake_yaw` verändert, würde der Regelkreis inkonsistent.

---

## Bekannte Grenzen / ehrlicher Stand

### Was gut abgesichert ist

- verwendete Unitree-Methoden und Message-Typen existieren in den hochgeladenen offiziellen Dateien
- die Bewegungs- und Standmodi sind direkt auf diesen Methoden aufgebaut
- die virtuelle Nav2-Odometrie ist konsistent mit dem hier gewählten Modell

### Was noch nicht als „fertig im Feld validiert“ gilt

- tatsächliches Verhalten unter deinem kompletten Nav2- und RTAB-Map-Setup
- Controller-Tuning für `look_yaw_kp`
- Pfadgüte bei starkem Schlupf oder großen Tracking-Fehlern
- ob alle benötigten Frame-Namen exakt zu deiner bestehenden Launch-/Nav2-Konfiguration passen

### Wichtigste offene Projektaufgabe

Wenn während aktiver Navigation in `balance_stand` gewechselt wird, sollte **ein anderer Teil des Projekts** den laufenden Nav2-Task abbrechen oder pausieren.

Diese Bridge dokumentiert diese Notwendigkeit, implementiert sie aber absichtlich nicht.

---

## Zusammenfassung

Diese Version der Bridge implementiert das gewünschte Grundmodell:

- Nav2 steuert die **Bahn**
- ein separater Look-Kanal steuert die **reale Basisorientierung**
- reale Rotation beeinflusst die Kartenbahn nicht
- `balance_stand` ist als separater Modus vorhanden
- für Nav2 wird eine **virtuelle** Odom-/TF-Sicht bereitgestellt

Damit ist die Bridge inhaltlich deutlich näher an deinem gewünschten Verhalten als eine normale `cmd_vel -> Move(...)`-Weiterleitung.
