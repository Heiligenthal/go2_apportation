#include <algorithm>
#include <chrono>
#include <cmath>
#include <memory>
#include <string>

#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "geometry_msgs/msg/vector3.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32.hpp"
#include "std_msgs/msg/string.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h"
#include "unitree_go/msg/sport_mode_state.hpp"

#include "go2_nav2_bridge/ros2_sport_client.h"

using namespace std::chrono_literals;

namespace go2_nav2_bridge
{

enum class GaitMode
{
  kNoChange,
  kStaticWalk,
  kTrotRun,
  kEconomicGait,
  kFreeWalk,
  kClassicWalk,
};

enum class ControlMode
{
  kVelocityMove,
  kBalanceStand,
};

class Go2Nav2Bridge : public rclcpp::Node
{
public:
  Go2Nav2Bridge()
  : Node("go2_nav2_bridge"), sport_client_(this)
  {
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", "/cmd_vel_nav2");
    sport_state_topic_ = declare_parameter<std::string>("sport_state_topic", "lf/sportmodestate");
    control_mode_topic_ = declare_parameter<std::string>("control_mode_topic", "/control_mode_cmd");
    look_yaw_delta_topic_ = declare_parameter<std::string>("look_yaw_delta_topic", "/look_yaw_delta");
    balance_rpy_topic_ = declare_parameter<std::string>("balance_rpy_topic", "/balance_rpy_cmd");
    nav2_odom_topic_ = declare_parameter<std::string>("nav2_odom_topic", "/odom_nav2");
    nav2_odom_frame_ = declare_parameter<std::string>("nav2_odom_frame", "odom_nav2");
    nav2_base_frame_ = declare_parameter<std::string>("nav2_base_frame", "base_link_nav2");
    publish_nav2_odom_ = declare_parameter<bool>("publish_nav2_odom", true);
    publish_nav2_tf_ = declare_parameter<bool>("publish_nav2_tf", true);

    watchdog_timeout_sec_ = declare_parameter<double>("watchdog_timeout_sec", 0.30);
    command_publish_rate_hz_ = declare_parameter<double>("command_publish_rate_hz", 20.0);
    max_vx_ = declare_parameter<double>("max_vx", 0.40);
    max_vy_ = declare_parameter<double>("max_vy", 0.25);
    max_wz_ = declare_parameter<double>("max_wz", 0.60);
    look_yaw_kp_ = declare_parameter<double>("look_yaw_kp", 1.5);
    nav2_linear_y_enabled_ = declare_parameter<bool>("nav2_linear_y_enabled", false);
    require_standup_on_start_ = declare_parameter<bool>("require_standup_on_start", false);
    enable_joystick_override_ = declare_parameter<bool>("enable_joystick_override", false);
    gait_mode_ = gaitFromString(declare_parameter<std::string>("gait_mode", "no_change"));

    auto qos = rclcpp::QoS(rclcpp::KeepLast(20));

    cmd_vel_sub_ = create_subscription<geometry_msgs::msg::Twist>(
      cmd_vel_topic_, qos,
      std::bind(&Go2Nav2Bridge::cmdVelCallback, this, std::placeholders::_1));

    sport_state_sub_ = create_subscription<unitree_go::msg::SportModeState>(
      sport_state_topic_, qos,
      std::bind(&Go2Nav2Bridge::sportStateCallback, this, std::placeholders::_1));

    control_mode_sub_ = create_subscription<std_msgs::msg::String>(
      control_mode_topic_, qos,
      std::bind(&Go2Nav2Bridge::controlModeCallback, this, std::placeholders::_1));

    look_yaw_delta_sub_ = create_subscription<std_msgs::msg::Float32>(
      look_yaw_delta_topic_, qos,
      std::bind(&Go2Nav2Bridge::lookYawDeltaCallback, this, std::placeholders::_1));

    balance_rpy_sub_ = create_subscription<geometry_msgs::msg::Vector3>(
      balance_rpy_topic_, qos,
      std::bind(&Go2Nav2Bridge::balanceRpyCallback, this, std::placeholders::_1));

    if (publish_nav2_odom_) {
      nav2_odom_pub_ = create_publisher<nav_msgs::msg::Odometry>(nav2_odom_topic_, qos);
    }
    if (publish_nav2_tf_) {
      tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
    }

    const auto period = std::chrono::duration<double>(1.0 / std::max(1.0, command_publish_rate_hz_));
    control_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::milliseconds>(period),
      std::bind(&Go2Nav2Bridge::controlLoop, this));

    last_control_time_ = now();
    last_cmd_time_ = now();

    if (require_standup_on_start_) {
      sport_client_.StandUp(req_);
    }
    if (enable_joystick_override_) {
      sport_client_.SwitchJoystick(req_, true);
    }
    applyConfiguredGait();

    RCLCPP_INFO(get_logger(), "go2_nav2_bridge ready");
    RCLCPP_INFO(get_logger(), "cmd_vel=%s sport_state=%s mode_topic=%s look_topic=%s", cmd_vel_topic_.c_str(),
      sport_state_topic_.c_str(), control_mode_topic_.c_str(), look_yaw_delta_topic_.c_str());
    RCLCPP_INFO(get_logger(), "publish_nav2_odom=%s publish_nav2_tf=%s nav2_linear_y_enabled=%s",
      publish_nav2_odom_ ? "true" : "false", publish_nav2_tf_ ? "true" : "false",
      nav2_linear_y_enabled_ ? "true" : "false");
    RCLCPP_WARN(get_logger(), "Important: If you switch to balance_stand while Nav2 is active, another part of the system should cancel the active Nav2 task.");
  }

private:
  static double clamp(double value, double lo, double hi)
  {
    return std::max(lo, std::min(value, hi));
  }

  static double normalizeAngle(double angle)
  {
    while (angle > M_PI) {
      angle -= 2.0 * M_PI;
    }
    while (angle < -M_PI) {
      angle += 2.0 * M_PI;
    }
    return angle;
  }

  static GaitMode gaitFromString(const std::string & value)
  {
    if (value == "static_walk") return GaitMode::kStaticWalk;
    if (value == "trot_run") return GaitMode::kTrotRun;
    if (value == "economic_gait") return GaitMode::kEconomicGait;
    if (value == "free_walk") return GaitMode::kFreeWalk;
    if (value == "classic_walk") return GaitMode::kClassicWalk;
    return GaitMode::kNoChange;
  }

  void applyConfiguredGait()
  {
    switch (gait_mode_) {
      case GaitMode::kStaticWalk:
        sport_client_.StaticWalk(req_);
        break;
      case GaitMode::kTrotRun:
        sport_client_.TrotRun(req_);
        break;
      case GaitMode::kEconomicGait:
        sport_client_.EconomicGait(req_);
        break;
      case GaitMode::kFreeWalk:
        sport_client_.FreeWalk(req_);
        break;
      case GaitMode::kClassicWalk:
        sport_client_.ClassicWalk(req_, true);
        break;
      case GaitMode::kNoChange:
      default:
        break;
    }
  }

  void cmdVelCallback(const geometry_msgs::msg::Twist::SharedPtr msg)
  {
    latest_nav_cmd_ = *msg;
    last_cmd_time_ = now();
  }

  void sportStateCallback(const unitree_go::msg::SportModeState::SharedPtr msg)
  {
    last_state_ = *msg;
    state_received_ = true;

    real_x_ = msg->position[0];
    real_y_ = msg->position[1];
    real_z_ = msg->position[2];
    real_vx_world_ = msg->velocity[0];
    real_vy_world_ = msg->velocity[1];
    real_vz_world_ = msg->velocity[2];
    real_yaw_ = msg->imu_state.rpy[2];

    if (!yaw_initialized_) {
      fake_yaw_ = real_yaw_;
      look_yaw_target_world_ = real_yaw_;
      yaw_initialized_ = true;
    }

    publishNav2Odometry(now());
  }

  void controlModeCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    const std::string & value = msg->data;
    if (value == "velocity_move") {
      if (control_mode_ != ControlMode::kVelocityMove) {
        control_mode_ = ControlMode::kVelocityMove;
        mode_just_changed_ = true;
        look_yaw_target_world_ = real_yaw_;
        RCLCPP_INFO(get_logger(), "Switched to velocity_move");
      }
      return;
    }

    if (value == "balance_stand") {
      if (control_mode_ != ControlMode::kBalanceStand) {
        control_mode_ = ControlMode::kBalanceStand;
        mode_just_changed_ = true;
        balance_yaw_ = real_yaw_;
        RCLCPP_INFO(get_logger(), "Switched to balance_stand");
      }
      return;
    }

    RCLCPP_WARN(get_logger(), "Unknown control mode '%s'", value.c_str());
  }

  void lookYawDeltaCallback(const std_msgs::msg::Float32::SharedPtr msg)
  {
    if (!yaw_initialized_) {
      RCLCPP_WARN(get_logger(), "Ignoring look_yaw_delta before first state message");
      return;
    }
    look_yaw_target_world_ = normalizeAngle(look_yaw_target_world_ + static_cast<double>(msg->data));
  }

  void balanceRpyCallback(const geometry_msgs::msg::Vector3::SharedPtr msg)
  {
    balance_roll_ = msg->x;
    balance_pitch_ = msg->y;
    balance_yaw_ = msg->z;
  }

  void controlLoop()
  {
    const auto now_time = now();
    const double dt = std::max(0.0, (now_time - last_control_time_).seconds());
    last_control_time_ = now_time;

    if (!state_received_ || !yaw_initialized_) {
      return;
    }

    if (control_mode_ == ControlMode::kVelocityMove) {
      runVelocityMove(now_time, dt);
    } else {
      runBalanceStand();
    }

    publishNav2Odometry(now_time);
  }

  void runVelocityMove(const rclcpp::Time & now_time, double dt)
  {
    if (mode_just_changed_) {
      sport_client_.StopMove(req_);
      mode_just_changed_ = false;
    }

    const double age = (now_time - last_cmd_time_).seconds();
    const bool command_fresh = age <= watchdog_timeout_sec_;

    const double nav_vx = command_fresh ? clamp(latest_nav_cmd_.linear.x, -max_vx_, max_vx_) : 0.0;
    const double nav_vy = (command_fresh && nav2_linear_y_enabled_) ? clamp(latest_nav_cmd_.linear.y, -max_vy_, max_vy_) : 0.0;
    const double nav_wz = command_fresh ? clamp(latest_nav_cmd_.angular.z, -max_wz_, max_wz_) : 0.0;

    fake_yaw_ = normalizeAngle(fake_yaw_ + nav_wz * dt);

    if (!command_fresh && std::abs(nav_vx) < 1e-6 && std::abs(nav_vy) < 1e-6) {
      sport_client_.StopMove(req_);
      return;
    }

    const double world_vx = std::cos(fake_yaw_) * nav_vx - std::sin(fake_yaw_) * nav_vy;
    const double world_vy = std::sin(fake_yaw_) * nav_vx + std::cos(fake_yaw_) * nav_vy;

    const double body_vx = std::cos(real_yaw_) * world_vx + std::sin(real_yaw_) * world_vy;
    const double body_vy = -std::sin(real_yaw_) * world_vx + std::cos(real_yaw_) * world_vy;

    const double yaw_error = normalizeAngle(look_yaw_target_world_ - real_yaw_);
    const double body_wz = clamp(look_yaw_kp_ * yaw_error, -max_wz_, max_wz_);

    sport_client_.Move(req_, static_cast<float>(clamp(body_vx, -max_vx_, max_vx_)),
      static_cast<float>(clamp(body_vy, -max_vy_, max_vy_)),
      static_cast<float>(body_wz));
  }

  void runBalanceStand()
  {
    if (mode_just_changed_) {
      sport_client_.StopMove(req_);
      sport_client_.BalanceStand(req_);
      mode_just_changed_ = false;
    }
    sport_client_.Euler(req_, static_cast<float>(balance_roll_), static_cast<float>(balance_pitch_), static_cast<float>(balance_yaw_));
  }

  void publishNav2Odometry(const rclcpp::Time & stamp)
  {
    if (!publish_nav2_odom_ || !nav2_odom_pub_) {
      return;
    }

    nav_msgs::msg::Odometry odom;
    odom.header.stamp = stamp;
    odom.header.frame_id = nav2_odom_frame_;
    odom.child_frame_id = nav2_base_frame_;

    odom.pose.pose.position.x = real_x_;
    odom.pose.pose.position.y = real_y_;
    odom.pose.pose.position.z = real_z_;

    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, fake_yaw_);
    odom.pose.pose.orientation.x = q.x();
    odom.pose.pose.orientation.y = q.y();
    odom.pose.pose.orientation.z = q.z();
    odom.pose.pose.orientation.w = q.w();

    // Real world velocity, but expressed in the virtual Nav2 base frame.
    odom.twist.twist.linear.x = std::cos(fake_yaw_) * real_vx_world_ + std::sin(fake_yaw_) * real_vy_world_;
    odom.twist.twist.linear.y = -std::sin(fake_yaw_) * real_vx_world_ + std::cos(fake_yaw_) * real_vy_world_;
    odom.twist.twist.linear.z = real_vz_world_;
    const double nav_cmd_age = (stamp - last_cmd_time_).seconds();
    odom.twist.twist.angular.z = nav_cmd_age <= watchdog_timeout_sec_ ? latest_nav_cmd_.angular.z : 0.0;

    odom.pose.covariance = {
      0.05, 0, 0, 0, 0, 0,
      0, 0.05, 0, 0, 0, 0,
      0, 0, 0.10, 0, 0, 0,
      0, 0, 0, 0.20, 0, 0,
      0, 0, 0, 0, 0.20, 0,
      0, 0, 0, 0, 0, 0.10};

    odom.twist.covariance = {
      0.10, 0, 0, 0, 0, 0,
      0, 0.10, 0, 0, 0, 0,
      0, 0, 0.15, 0, 0, 0,
      0, 0, 0, 0.30, 0, 0,
      0, 0, 0, 0, 0.30, 0,
      0, 0, 0, 0, 0, 0.15};

    nav2_odom_pub_->publish(odom);

    if (publish_nav2_tf_ && tf_broadcaster_) {
      geometry_msgs::msg::TransformStamped tf_msg;
      tf_msg.header.stamp = stamp;
      tf_msg.header.frame_id = nav2_odom_frame_;
      tf_msg.child_frame_id = nav2_base_frame_;
      tf_msg.transform.translation.x = real_x_;
      tf_msg.transform.translation.y = real_y_;
      tf_msg.transform.translation.z = real_z_;
      tf_msg.transform.rotation.x = q.x();
      tf_msg.transform.rotation.y = q.y();
      tf_msg.transform.rotation.z = q.z();
      tf_msg.transform.rotation.w = q.w();
      tf_broadcaster_->sendTransform(tf_msg);
    }
  }

  SportClient sport_client_;
  unitree_api::msg::Request req_;
  unitree_go::msg::SportModeState last_state_{};
  geometry_msgs::msg::Twist latest_nav_cmd_{};
  bool state_received_{false};
  bool yaw_initialized_{false};
  bool mode_just_changed_{false};

  std::string cmd_vel_topic_;
  std::string sport_state_topic_;
  std::string control_mode_topic_;
  std::string look_yaw_delta_topic_;
  std::string balance_rpy_topic_;
  std::string nav2_odom_topic_;
  std::string nav2_odom_frame_;
  std::string nav2_base_frame_;
  bool publish_nav2_odom_{true};
  bool publish_nav2_tf_{true};
  double watchdog_timeout_sec_{0.30};
  double command_publish_rate_hz_{20.0};
  double max_vx_{0.40};
  double max_vy_{0.25};
  double max_wz_{0.60};
  double look_yaw_kp_{1.5};
  bool nav2_linear_y_enabled_{false};
  bool require_standup_on_start_{false};
  bool enable_joystick_override_{false};
  GaitMode gait_mode_{GaitMode::kNoChange};
  ControlMode control_mode_{ControlMode::kVelocityMove};

  double real_x_{0.0};
  double real_y_{0.0};
  double real_z_{0.0};
  double real_vx_world_{0.0};
  double real_vy_world_{0.0};
  double real_vz_world_{0.0};
  double real_yaw_{0.0};
  double fake_yaw_{0.0};
  double look_yaw_target_world_{0.0};
  double balance_roll_{0.0};
  double balance_pitch_{0.0};
  double balance_yaw_{0.0};

  rclcpp::Time last_cmd_time_;
  rclcpp::Time last_control_time_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  rclcpp::Subscription<unitree_go::msg::SportModeState>::SharedPtr sport_state_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr control_mode_sub_;
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr look_yaw_delta_sub_;
  rclcpp::Subscription<geometry_msgs::msg::Vector3>::SharedPtr balance_rpy_sub_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr nav2_odom_pub_;
  rclcpp::TimerBase::SharedPtr control_timer_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
};

}  // namespace go2_nav2_bridge

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<go2_nav2_bridge::Go2Nav2Bridge>());
  rclcpp::shutdown();
  return 0;
}
